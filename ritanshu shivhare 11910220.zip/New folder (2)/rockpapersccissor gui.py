""" following u have to domnload
1-pip install pyttsx3
2-tkinker 
3-import random libary
4-pip install SpeechRecognition
5-import datetime
"""

from tkinter import *
import random
import tkinter
import pyttsx3 
import datetime
import speech_recognition as sr 
engine = pyttsx3.init("sapi5")
voices = engine.getProperty("voices")
#print(voices)

engine.setProperty("voice",voices[1].id)
print(voices[1].id)
def speak(audio):
    engine.say(audio)
    engine.runAndWait()
def wishing():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("good morning by jarvis")
    elif(hour>=12 and hour<18):
        speak("goodafternoon by jarvis")
    else:
        speak("good evening by jarvis")
if __name__ == "__main__":
    wishing()
   
engine = pyttsx3.init() 
  
engine.setProperty('rate', 150)  
engine.setProperty('volume', 55)



engine.setProperty("voice",voices[1].id) 
engine.say("so before starting of the game you should know rules of the games after this you listen rule of the game")
engine.runAndWait()
engine.say("Winning Rules of the Rock paper scissor game as following: "
                                +"Rock vs paper because paper paper covers rock=paper wins "
                                + "Rock vs scissor because rock breaks sccissor=Rock wins"
                                +"paper vs scissor scissor cut paper =scissor wins ")

 
engine.say(" i hope you listen the rules of the game as per now you know the rules of the games now so we can start now")
engine.runAndWait()




user = int
computer = int
win = 0
lose = 0
def rps(win, lose, user):
    computer = random.randrange(1,4)
    if user == computer:
        var.set("It's a draw. \n No Points")  
    elif user == 1 and computer == 3:
        var.set("You chose Rock, I chose Scissors. \nYou win")
        wins.set(wins.get() + 1)
            
    elif user == 1 and computer == 2:
        var.set("You chose Rock, I chose Paper. \nYou lose")
        lose += 1
        wins.set(wins.get() - 1)    
    elif user == 2 and computer == 1:
        var.set("You chose Paper, I chose Rock. \nYou win")
        wins.set(wins.get() + 1)
        wins.set(wins.get() - 1) 
        
    elif user == 2 and computer == 3:
        var.set("You chose Paper, I chose Scissors. \nYou lose")
        lose += 1
        wins.set(wins.get() - 1) 
        
    elif user == 3 and computer == 1:
        var.set("You chose Scissors, I chose Rock. \nYou lose")
        lose += 1
        wins.set(wins.get() - 1)    
    elif user == 3 and computer == 2:
        var.set("You chose Scissors, I chose Paper. \nYou win")
        wins.set(wins.get() + 1)
        
    elif user == 4 and computer == 3:
        var.set("You chose Spock, I chose Scissors. \nYou win")
        wins.set(wins.get() + 1)
        
    elif user == 4 and computer == 1:
        var.set("You chose Spock, I chose Rock. \nYou win")
        wins.set(wins.get() + 1)
        
    elif user == 4 and computer == 5:
        var.set("You chose Spock, I chose Lizard. \nYou lose")
        lose +=1
        wins.set(wins.get() - 1)
        
        
    elif user == 4 and computer == 2:
        var.set("You chose Spock, I chose Paper. \nYou lose")
        lose +=1
        wins.set(wins.get() - 1)
    elif user == 5 and computer == 1:
        
        var.set("You chose Lizard, I chose Rock. \nYou lose")
        lose +=1
        wins.set(wins.get() - 1)
    elif user == 5 and computer == 2:
        var.set("You chose Lizard, I chose Paper. \nYou win")
        wins.set(wins.get() + 1)
        
    elif user == 5 and computer == 3:
        var.set("You chose Lizard, I chose Scissors. \nYou lose")
        lose +=1
        wins.set(wins.get() - 1)
    elif user == 5 and computer == 4:
        var.set("You chose Lizard, I chose Spock. \nYou win")
        wins.set(wins.get() + 1)
        
    elif user == 1 and computer == 4:
        var.set("You chose Rock, I chose Spock. \nYou lose")
        lose +=1
        wins.set(wins.get() - 1)
    elif user == 2 and computer == 4:
        var.set("You chose Paper, I chose Spock. \nYou win")
        wins.set(wins.get() + 1)
        
    elif user == 3 and computer == 4:
        var.set("You chose Scissors, I chose Spock. \nYou lose")
        lose +=1
        wins.set(wins.get() - 1)
    elif user == 5 and computer == 4:
        var.set("You chose Lizard, I chose Spock. \nYou win")
        wins.set(wins.get() + 1)
        
    elif user == 1 and computer == 5:
        var.set("You chose Rock, I chose Lizard. \nYou win")
        wins.set(wins.get() + 1)
        
    elif user == 2 and computer == 5:
        var.set("You chose Paper, I chose Lizard. \nYou lose")
        lose +=1
        wins.set(wins.get() - 1)
    elif user == 3 and computer == 5:
        var.set("You chose Scissors, I chose Lizard. \nYou win")
        wins.set(wins.get() + 1)
        
    elif user == 4 and computer == 5:
        var.set("You chose Spock, I chose Lizard. \nYou lose")
        lose +=1
        wins.set(wins.get() - 1)  
    else:
        
        var.set("Thanks for playing. \nYou have " + str(win) + " wins and " + str(lose) + " losses.")


    
top = tkinter.Tk()
top.wm_title("RPS Python GUI")


top.minsize(width=350, height=150)
top.maxsize(width=350, height=150)


B1 = tkinter.Button(top, text ="Rock", command = lambda: rps(win, lose, 1))
B1.grid(row=0, column=1)
B2 = tkinter.Button(top, text ="Paper", command = lambda: rps(win, lose, 2))
B2.grid(row=0, column=2)
B3 = tkinter.Button(top, text ="Scissors", command = lambda: rps(win, lose, 3))
B3.grid(row=0, column=3)
space = tkinter.Label(top, text="")
space.grid(row=1)


var = StringVar()
var.set('Welcome!')
l = Label(top, textvariable = var)
l.grid(row=2, column=2)


wins = IntVar()
wins.set(win)
w = Label(top, textvariable = wins)


w.grid(row=4, column=2)
labeled = Label(top, text = "Score:")



labeled.grid(row=3, column=2)
copy = Label(top, text= "RPS GUI on Tkinter on Python.ritanshu 11910220")
copy.grid(row=5, column=2)
top.mainloop()